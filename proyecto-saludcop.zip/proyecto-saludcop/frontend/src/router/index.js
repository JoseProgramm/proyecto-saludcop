import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '../views/Home.vue';
import DetallesPaciente from '../views/DetallesPaciente.vue';
import Usuarios from '../views/Usuarios.vue';
Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    path: '*',
    redirect: '/',
  },
  {
    path: '/paciente/:pacienteID',
    name: 'DetallesPaciente',
    component: DetallesPaciente,
  },
  {
    path: '/usuarios',
    name: 'Usuarios',
    component: Usuarios,
  },
  {
    path: '/paciente-agregar',
    name: 'PacienteAgregar',
    component: () => import('../views/Paciente-Agregar.vue'),
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue'),
  },
  {
    path: '/registro',
    name: 'Registro',
    component: () => import('../views/Registro.vue'),
  },
  {
    path: '/paciente-alta',
    name: 'PacienteAlta',
    component: () => import('../views/Paciente-Alta.vue'),
  },
  {
    path: '/paciente-cola',
    name: 'PacienteCola',
    component: () => import('../views/Paciente-Cola.vue'),
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
